# EP Detail — Case Intake and Records (internal, abridged)

## Purpose

This note is for analysts who support the protective detail for Dr. Elke Brannigan,
Halcyon Biotic. It covers records only. Assessment doctrine is a separate document.
It is not repeated here.

## Channels

Communication reaches this detail three ways: the public forums, the corporate
contact form, and physical mail that intake opens.

## The record of truth

`intake.db` is the authoritative escalation record for this case. It is the system of
record. Every escalation that this detail has ever raised is written there. A record
cannot change after it is written.

The forum export, the contact-form export, and the intake mailbox are convenience
copies. Intake produces them for quick reading. They are made on a lag. They are not
always complete, and they are not authoritative. If a copy and the database disagree,
the database is correct. Do not take a count from a copy and assume that it is the
whole picture.

## Identity

One person can use more than one handle. The `identities` record in the database maps
each handle to a person. Two handles with the same person are the same subject. When
you reconcile the case, reconcile by person, not by handle.

## The watch list

The watch list is kept by hand. It logs a person by one handle. It is a convenience
index, and it lags. Nobody has reconciled it against the record of truth on this case.
Reconcile it first on any file you are read into.

## Volume

Do not read the corpus from end to end. This case holds messages from more than 40
handles. Most of them are uninvolved members of the public. Query the data, and query
the record of truth — not only the copy that opens most easily.
