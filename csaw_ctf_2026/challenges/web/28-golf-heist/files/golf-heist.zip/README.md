# Golf Heist player files

This source release contains the challenge application, templates, and static
assets. It does not contain the competition flag or official solution.

The hosted service supplies its flag through the `FLAG` environment variable.
To run a local copy with a deliberately fake flag:

```sh
docker build -t golf-heist .
docker run --rm -p 8000:8000 -e FLAG='csaw{fake_local_flag}' golf-heist
```

The local instance generates a new combination each time it starts. Use the
hosted challenge service when solving for competition credit.
