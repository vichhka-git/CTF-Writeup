<div id="nav-bar">
    <menu>
        <li><a href="index.php">Reanimate</a></li>
        <li><a href="register.php" >Join Us</a></li>
        <li><a href="login.php">Welcome Back</a></li>
    </menu>
</div>