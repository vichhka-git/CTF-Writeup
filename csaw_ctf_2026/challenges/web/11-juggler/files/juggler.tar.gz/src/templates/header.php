<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Juggler</title>
    <link rel="stylesheet" href="/css/main.css">
</head>
<body>
    <h1>Juggler</h1>