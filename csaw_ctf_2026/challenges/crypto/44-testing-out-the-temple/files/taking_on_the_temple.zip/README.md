# Midnight Vault player files

This is the source release for the challenge. It contains the Flask application,
player-facing cryptographic artifacts, and a complete local Docker setup, but no
deployment secrets, tests, or official solver.

The local Docker setup intentionally uses an obvious fake seed and fake flag. Its
generated suffixes and flag will not match the hosted competition instance.

Run the local instance with:

```sh
docker compose up --build
```

Use the hosted challenge instance to recover and submit the real flag. For source
inspection, the important files are `app/app.py` and `data/`.
