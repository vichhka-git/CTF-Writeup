import sys


ALLOWED = {
    "standard",
    "stealth",
    "audit",
    "sandbox",
    "forensics",
    "wireless",
    "bluetooth",
    "firmware",
}


def main() -> int:
    profile = sys.argv[1] if len(sys.argv) > 1 else ""
    if profile.lower() in ALLOWED:
        print(f"profile accepted:{profile}")
        return 0

    print(f"profile rejected:{profile}")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
