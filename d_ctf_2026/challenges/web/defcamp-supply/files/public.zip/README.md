# DefCamp Supply

Magazin web de echipamente pentru laboratoare de securitate. Instanța de challenge este furnizată de platformă.

Este inclusă o componentă backend relevantă pentru verificarea profilului personalizat. Restul logicii aplicației rulează pe serviciul remote.

Formatul flag-ului este `CTF{sha256}`.
