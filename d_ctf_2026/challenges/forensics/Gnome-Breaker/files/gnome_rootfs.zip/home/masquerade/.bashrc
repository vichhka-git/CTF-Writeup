# ~/.bashrc
alias ll='ls -alF'
export EDITOR=vim
enim todo photo dolor tempor aliquip elit magna nisi nostrud nostrud
consectetur dolore hint invoice holiday budget hint elit consequat nostrud
server config adipiscing reminder holiday budget backup config config receipt
amet