ls
cd .local/share/keyrings
xxd login.keyring | head
nmcli connection show
cat /etc/os-release
sudo apt update
htop
